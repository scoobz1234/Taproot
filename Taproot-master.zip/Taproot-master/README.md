# Taproot
UAT-Taproot Project

Stephen Ouellette - Project Lead - steouell@uat.edu  
Jose Ramirez - Netsec/Programmer - joseramir861@gmail.com<br>
Brandon Nay - Back End Lead - brandonnay21@gmail.com
Joey Selamat - joeyselamat@gmail.com
